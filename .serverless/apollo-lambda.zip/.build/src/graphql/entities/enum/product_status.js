"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productStatus = void 0;
var productStatus;
(function (productStatus) {
    productStatus["active"] = "active";
    productStatus["finished"] = "finished";
})(productStatus = exports.productStatus || (exports.productStatus = {}));
//# sourceMappingURL=product_status.js.map