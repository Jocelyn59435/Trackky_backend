export enum productStatus {
  active = 'active',
  finished = 'finished',
}
